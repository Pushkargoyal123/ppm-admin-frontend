# Changelog

# [1.3.2]

### Updated
- Packages updated
- Edited README.md

# [1.3.1]

### Updated
- Added link to flatlogic on login and register pages

# [1.3.0]

### Updated
- Update packages

### Fixed
- Header button on md adjusting
- Dashboard page make more responsive
- Notification page fix
- Tables page fix TableBody paddings

# [1.2.3]

### Updated
- Fixed security vulnerabilities in dependencies

# [1.2.2]

### Updated
- Packages updated

# [1.2.1]

### Updated
- Packages updated

### Fixed
- Sign up name type of input
- Dot component size prop
- Performance errors

# [1.2.0]

### Updated
- Packages update
- Link to Full version

### Fixed
- User login state improvements

## [1.1.0]

### New Feactures

- React v16.8.6
- React Router v5
- new React Hooks
- Material UI v4.3

Bug fixes

## [1.0.0]

Initial version of the project
